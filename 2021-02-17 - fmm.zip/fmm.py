# 2021-02-17

# implementation of han 2020 matrix multiplication algorithm; 
# we cover section 3.1 with second half of equation fourteen; 
# instead of "fast" incorrect approach of 
# ([2] to [4]) ^ e / (2 * (x + 1)) ^ e mod (x ^ 2 - 1), 
# we use slow "correct" approach of 
# (([2] to [4]) / (2 * (x + 1)) mod (x ^ 2 - 1)) ^ e mod (x ^ 2 - 1)

# however, we get the wrong answer for our arbitrary test case of 
# a = <4, 2, 3, 1>, b = <10, 11, 13, 4> and e == 2 and log(n) == 2; 
# r_1 is 400 (which we can reproduce) and r_2 is 610; 
# instead, we get 160000 for r_2

# we have commented out parts for solving a vandermonde system 
# as they require numpy

from collections import defaultdict
import math
# import numpy as np
from pld import poly_div

class Polynomial:

  def __init__(self):
    self.terms = []

  def _getTerms(self):
    return self.terms

  def _setTerms(self, terms):
    self.terms = terms

  # it is important that we do not combine terms with same power automatically
  def addTerm(self, c, q):
    self.terms.append((c, q))

  def toString(self):
    terms = self._getTerms()
    return terms

  # we do not collect terms
  @staticmethod
  def doMultiply(q1, q2):
    terms1 = q1._getTerms()
    terms2 = q2._getTerms()
    next_terms = []
    for term1 in terms1:
      c1, p1 = term1
      for term2 in terms2:
        c2, p2 = term2
        next_c = c1 * c2
        next_p = p1 + p2
        next_term = (next_c, next_p)
        next_terms.append(next_term)
    next_q = Polynomial()
    for term in next_terms:
      c, p = term
      next_q.addTerm(c, p)
    return next_q

  # we also remove terms with coefficient of zero
  def collectTerms(self):
    term_dict = defaultdict(lambda: 0)
    terms = self._getTerms()
    for term in terms:
      c, p = term
      term_dict[p] += c
    next_term_dict = {}
    for term in term_dict.items():
      p, c = term
      if c == 0:
        continue
      next_term_dict[p] = c
    next_terms = [(x[1], x[0]) for x in next_term_dict.items()]
    self._setTerms(next_terms)

  def clone(self):
    p = Polynomial()
    p._setTerms(self._getTerms()[ : ])
    return p

  def getCoefficients(self):
    terms = self._getTerms()
    result = [x[0] for x in terms]
    return result

  # we do not collect terms
  @staticmethod
  def doAdd(q1, q2):
    next_q = Polynomial()
    terms1 = q1._getTerms()
    terms2 = q2._getTerms()
    next_terms = terms1 + terms2
    for next_term in next_terms:
      c, p = next_term
      next_q.addTerm(c, p)
    return next_q

  @staticmethod
  def doScalarDivision(q, s):
    next_q = Polynomial()
    terms = q._getTerms()
    next_terms = [(x[0] / (1. * s), x[1]) for x in terms]
    for next_term in next_terms:
      c, p = next_term
      next_q.addTerm(c, p)
    return next_q

  # we assume power is an integer that is at least one; 
  # we do not automatically collect terms
  @staticmethod
  def doRaiseToPower(q, power):
    terms = q._getTerms()
    curr_q = q.clone()
    for m in xrange(power - 1):
      curr_q = Polynomial.doMultiply(curr_q, q)
    return curr_q

  @staticmethod
  def collectSameSignTerms(q):
    terms = q._getTerms()
    curr_q = Polynomial()
    p_to_pos_c_dict = defaultdict(lambda: 0)
    p_to_neg_c_dict = defaultdict(lambda: 0)
    for term in terms:
      c, p = term
      if c < 0:
        p_to_neg_c_dict[p] += c
      elif c > 0:
        p_to_pos_c_dict[p] += c
    for item in p_to_neg_c_dict.items():
      p, c = item
      curr_q.addTerm(c, p)
    for item in p_to_pos_c_dict.items():
      p, c = item
      curr_q.addTerm(c, p)
    return curr_q

def doDotProduct(a, b):
  addends = [a[i] * b[i] for i in xrange(len(a))]
  result = sum(addends)
  return result

"""

v = doDotProduct(a, b)
print v

"""

# k is zero-indexed and starts at LSB
def getBit(v, k):
  return (v & (1 << k)) >> k

"""

print "bit:", getBit(13, 0)
print "bit:", getBit(13, 1)
print "bit:", getBit(13, 2)
print "bit:", getBit(13, 3)

"""

# this is a brute-force approach; 
# e >= 1 and e is an integer; 
# when e == 1, time is in O(num_index_bits)
def doCircleMultiply(i, j, num_index_bits, e):
  base_factor = None
  coefficients = []
  for k in xrange(num_index_bits):
    b1 = getBit(i, k)
    b2 = getBit(j, k)
    c1 = b1 * b2
    b3 = 1 - b1
    b4 = 1 - b2
    c2 = b3 * b4
    coefficients.append(c1)
    coefficients.append(c2)
  # we don't actually have to expand the base factor before raising to e
  curr_value = sum(coefficients)
  result = curr_value ** e
  return result

# brute-force approach
def computeRe(a, b, num_index_bits, e):
  n = len(a)
  result = 0
  for i in xrange(n):
    a_i = a[i]
    for j in xrange(n):
      b_j = b[j]
      weight = doCircleMultiply(i, j, num_index_bits, e)
      v = a_i * weight * b_j
      result += v
  return result

# have four main addends

# for pre-processing
def makeAP1Scalar(v, n, num_index_bits):
  result = 0
  for i in xrange(n):
    for k1 in xrange(num_index_bits):
      b1 = getBit(i, k1)
      b2 = 1 - b1
      c1 = v[i] * (b1 + b2)
      result += c1
  return result

# for pre-processing
def makeBP1Scalar(v, n, num_index_bits):
  result = 0
  for j in xrange(n):
    for k2 in xrange(num_index_bits):
      b1 = getBit(j, k2)
      b2 = 1 - b1
      c1 = v[j] * (b1 + b2)
      result += c1
  return result

# for query-time
def makeP1(s1, s2, num_index_bits):
  p = Polynomial()
  curr_coefficient = s1 * s2
  curr_exponent = num_index_bits * 4 + 7
  p.addTerm(curr_coefficient, curr_exponent)
  return p

# for pre-processing
def makeAP2(v, n, num_index_bits):
  p = Polynomial()
  for i in xrange(n):
    for k1 in xrange(num_index_bits):
      b1 = getBit(i, k1)
      b2 = 1 - b1
      c1 = b1 * v[i]
      c2 = b2 * v[i]
      q1 = 4 * k1
      q2 = 4 * k1 + 2
      p.addTerm(c1, q1)
      p.addTerm(c2, q2)
  p.collectTerms()
  return p

# for pre-processing
def makeBP2(v, n, num_index_bits):
  p = Polynomial()
  for j in xrange(n):
    for k2 in xrange(num_index_bits):
      b1 = getBit(j, k2)
      b2 = 1 - b1
      c1 = b1 * v[j]
      c2 = b2 * v[j]
      q1 = -4 * k2 + 4 * num_index_bits + 6
      q2 = -4 * k2 - 2 + 4 * num_index_bits + 6
      p.addTerm(c1, q1)
      p.addTerm(c2, q2)
  p.collectTerms()
  return p

# for pre-processing
def makeAP3Scalar(v, n, num_index_bits):
  result = 0
  for i in xrange(n):
    for k1 in xrange(num_index_bits):
      b1 = getBit(i, num_index_bits - 1 - k1)
      b2 = 1 - b1
      c1 = v[i] * (b1 + b2)
      result += c1
  return result

# for pre-processing
def makeBP3Scalar(v, n, num_index_bits):
  result = 0
  for j in xrange(n):
    for k2 in xrange(num_index_bits):
      b1 = getBit(j, num_index_bits - 1 - k2)
      b2 = 1 - b1
      c1 = v[j] * (b1 + b2)
      result += c1
  return result

# for query-time
def makeP3(s1, s2, num_index_bits):
  p = Polynomial()
  curr_coefficient = s1 * s2
  curr_exponent = num_index_bits * 4 + 7
  p.addTerm(curr_coefficient, curr_exponent)
  return p

# for pre-processing
def makeAP4(v, n, num_index_bits):
  p = Polynomial()
  for i in xrange(n):
    for k1 in xrange(num_index_bits):
      b1 = getBit(i, num_index_bits - 1 - k1)
      b2 = 1 - b1
      c1 = b1 * v[i]
      c2 = b2 * v[i]
      q1 = 4 * k1 + 2
      q2 = 4 * k1
      p.addTerm(c1, q1)
      p.addTerm(c2, q2)
  p.collectTerms()
  return p

# for pre-processing
def makeBP4(v, n, num_index_bits):
  p = Polynomial()
  for j in xrange(n):
    for k2 in xrange(num_index_bits):
      b1 = getBit(j, num_index_bits - 1 - k2)
      b2 = 1 - b1
      c1 = b1 * v[j]
      c2 = b2 * v[j]
      q1 = -4 * k2 + 4 * num_index_bits + 6 - 2
      q2 = -4 * k2 + 4 * num_index_bits + 6
      p.addTerm(c1, q1)
      p.addTerm(c2, q2)
  p.collectTerms()
  return p

# divide by (x + 1); 
# we assume terms are collected ahead of time; 
# we assume no remainder exists
def doHanDiv(p):
  terms = p._getTerms()
  max_degree = max([x[1] for x in terms])
  # print "max. degree:", max_degree
  N = [0] * (max_degree + 1)
  for term in terms:
    c, p = term
    N[p] = c
  # we do indeed tend to be divisible by (x + 1)
  D = [1, 1]
  result = poly_div(N, D)
  quotient, remainder = result
  # raise Exception()
  # print "quotient:", quotient
  result_q = Polynomial()
  for i in xrange(len(quotient)):
    c = quotient[i]
    p = i
    result_q.addTerm(c, p)
  return result_q

# output is two polynomials -- one with all positive coefficients and one with all negative coefficients; we also collect terms; we assume exponents are non-negative integers
def doRewriteWithSignSeparation(q):
  terms = q._getTerms()
  q_pos = Polynomial()
  q_neg = Polynomial()
  # print terms
  # raise Exception()
  for term in terms:
    c, p = term
    if c < 0:
      # even
      if p % 2 == 0:
        q_neg.addTerm(c, 0)
      # odd
      elif p % 2 == 1:
        q_neg.addTerm(c, 1)
    elif c > 0:
      # even
      if p % 2 == 0:
        q_pos.addTerm(c, 0)
      # odd
      elif p % 2 == 1:
        q_pos.addTerm(c, 1)
  q_pos.collectTerms()
  q_neg.collectTerms()
  return (q_pos, q_neg)

if __name__ == "__main__":

  print "HANDLING MAIN VECTOR PAIR"
  print

  a = [4, 2, 3, 1]
  b = [10, 11, 13, 4]

  print "vector a:", a
  print "vector b:", b

  n = 4

  print "n:", 4

  num_index_bits = int(math.ceil(math.log(n, 2)))

  print "num. of index bits:", num_index_bits

  # v = doCircleMultiply(2, 3, num_index_bits, 1)
  v = doCircleMultiply(3, 3, num_index_bits, 1)
  
  print "3 circle-multiply 3 is:", v
  
  # e is 1-indexed
  r_e = computeRe(a, b, num_index_bits, 1)
  print "r_1 is:", r_e
  
  r_e_list = [computeRe(a, b, num_index_bits, i + 1) for i in xrange(num_index_bits)]
  print "r_e values are:", r_e_list

  print
  
  """
  
  # we solve a vandermonde
  # A * X = B
  
  # matrix via rows
  A = np.array([[1, 2], [1, 4]])
  # y values
  B = np.array([400, 610])
  # x values
  X = np.linalg.solve(A,B)
  
  print X
  
  dot_product = X[1]
  
  print "semi-brute-force result:", dot_product
  
  """

  def handleMainPolynomial(a, b, n, num_index_bits, e):

    s1 = makeAP1Scalar(a, n, num_index_bits)
    s2 = makeBP1Scalar(b, n, num_index_bits)
    t1 = makeP1(s1, s2, num_index_bits)
    t2 = makeAP2(a, n, num_index_bits)
    t3 = makeBP2(b, n, num_index_bits)
    s3 = makeAP3Scalar(a, n, num_index_bits)
    s4 = makeBP3Scalar(b, n, num_index_bits)
    t4 = makeP3(s3, s4, num_index_bits)
    t5 = makeAP4(a, n, num_index_bits)
    t6 = makeBP4(b, n, num_index_bits)
    
    """
  
    print t1, t2, t3, t4, t5, t6
    print t1.toString()
    print t2.toString()
    print t3.toString()
    print t4.toString()
    print t5.toString()
    print t6.toString()
  
    """
  
    t7 = Polynomial.doMultiply(t2, t3)
    t7.collectTerms()
    t8 = Polynomial.doMultiply(t5, t6)
    t8.collectTerms()
    t9 = Polynomial.doAdd(t1, t7)
    t9.collectTerms()
    t10 = Polynomial.doAdd(t9, t4)
    t10.collectTerms()
    t11 = Polynomial.doAdd(t10, t8)
    t11.collectTerms()
    
    # print t11.toString()
    
    t12 = Polynomial.doScalarDivision(t11, 2)
    
    # print t12.toString()
    
    # unsure if this is safe
    t12.collectTerms()
    
    t13 = doHanDiv(t12)
    # print t13.toString()
    
    result = doRewriteWithSignSeparation(t13)
    t14, t15 = result
    # print t14.toString()
    # print t15.toString()
    
    # we must make sure terms for same exponent are not automatically combined
    t16 = Polynomial.doAdd(t14, t15)
    
    # e = 2
    # e = 1
    t17 = Polynomial.doRaiseToPower(t16, e)
    # print t17.toString()
    # raise Exception()
    
    t18 = Polynomial.collectSameSignTerms(t17)
    
    # print t18.toString()
    
    result = doRewriteWithSignSeparation(t18)
    t19, t20 = result
    return result
  
  def makeExamplePolynomial():
    p1 = Polynomial()
    p1.addTerm(1, 5)
    p1.addTerm(1, 2)
    p1.addTerm(1, 5)
    p1.addTerm(1, 6)
    # we have to collect prior to han-division step
    p1.collectTerms()
    p2 = Polynomial.doScalarDivision(p1, 2)
    p3 = doHanDiv(p2)
    # print p3.toString()
    p4 = Polynomial.doRaiseToPower(p3, 2)
    p5 = Polynomial.collectSameSignTerms(p4)
    result = doRewriteWithSignSeparation(p5)
    p6, p7 = result
    return result

  r1 = handleMainPolynomial(a, b, n, num_index_bits, 1)
  p1, p2 = r1
  print "(showing details relating to resolving c_{11} for e == 1)"
  print
  print "positive coefficients for x ^ 0 and x ^ 1:"
  print p1.toString()
  print "negative coefficients for x ^ 0 and x ^ 1:"
  print p2.toString()
  print

  r2 = handleMainPolynomial(a, b, n, num_index_bits, 2)
  p3, p4 = r2
  print "(showing details relating to resolving c_{11} for e == 2)"
  print
  print "positive coefficients for x ^ 0 and x ^ 1:"
  print p3.toString()
  print "negative coefficients for x ^ 0 and x ^ 1:"
  print p4.toString()
  print

  print "HANDLING EXAMPLE POLYNOMIAL FROM PAGE TWELVE"
  print

  r3 = makeExamplePolynomial()
  p5, p6 = r3
  print "(showing details relating to resolving c_{11} for e == 2)"
  print
  print "positive coefficients for x ^ 0 and x ^ 1:"
  print p5.toString()
  print "negative coefficients for x ^ 0 and x ^ 1:"
  print p6.toString()

  """
  
  # say we are given 3 / 2 - 1 / 2 + x - x -- this is: 
  # [(1.5, 0), (1.0, 1)]
  # [(-0.5, 0), (-1.0, 1)]
  
  # (1.0, 0) and (-1.0, 1) cancel (UL and LR)
  
  # (-0.5, 0) and (0.5, 1) cancel (LL and UR)
  
  # then, we have:
  # [(0.5, 0), (0.5, 1)]
  # [(0, 0), (0, 0)]
  
  # x == -1
  # => 0.5 + (-1 * 0.5) = 0.5 - 0.5 = 0
  
  """
  
  """
  
  # say we are given (given that we are hoping for 400):
  # [(1871, 0), (911, 1)]
  # [(-351, 0), (-911, 1)]
  
  # (911, 0) and (-911, 1) cancel (UL and LR)
  
  # (-351, 0) and (351, 1) cancel (LL and UR)
  
  # then, we have:
  # [(960, 0), (560, 1)]
  # [(0, 0), (0, 1)]
  
  # x == -1
  # => 960 + (-1 * 560) = 960 - 560 = 400
  
  """
  
  """
  
  # say we are given (given that we are hoping for 610):
  # [(5283684.0, 0), (4048484.0, 1)]
  # [(-2973284.0, 0), (-4048484.0, 1)]
  
  # (4048484, 0) and (-4048484, 1) cancel (UL and LR)
  
  # (-2973284, 0) and (2973284, 1) cancel (LL and UR)
  
  # then, we have:
  # [(1235200, 0), (1075200, 1)]
  # [(0, 0), (0, 0)]
  
  # x == -1
  # => 1235200 + (-1 * 1075200) = 1235200 - 1075200 = 160000 (i.e. a wrong answer)
  
  """


